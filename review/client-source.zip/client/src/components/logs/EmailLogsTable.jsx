import React, { useState } from "react";
import Badge from "../common/Badge";

/**
 * Filterable table displaying outgoing email delivery logs with status indicators and search.
 *
 * @param {Object} props
 * @param {Array<Object>} props.logs - Array of email log documents
 * @param {boolean} [props.isLoading=false] - Loading spinner state
 * @param {Function} [props.onSelectLog] - Triggered when clicking a row to view full raw headers & payload
 * @param {Function} [props.onResend] - Triggered when manually retrying a failed/bounced delivery
 */
export default function EmailLogsTable({
  logs = [],
  isLoading = false,
  onSelectLog,
  onResend,
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const getStatusBadge = (status) => {
    switch (status?.toUpperCase()) {
      case "DELIVERED":
        return <Badge variant="success">Delivered</Badge>;
      case "BOUNCED":
        return <Badge variant="danger">Bounced</Badge>;
      case "COMPLAINED":
        return <Badge variant="danger">Spam Report</Badge>;
      case "QUEUED":
      case "SENDING":
        return <Badge variant="warning">Queued</Badge>;
      default:
        return <Badge variant="neutral">{status || "Unknown"}</Badge>;
    }
  };

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.recipient?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.subject?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.messageId?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "ALL" || log.status?.toUpperCase() === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
      {/* Controls Bar */}
      <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <input
            type="text"
            placeholder="Search recipient, subject, or Message-ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border border-gray-300 rounded-lg px-3.5 py-2 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-80"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
          {["ALL", "DELIVERED", "BOUNCED", "QUEUED", "COMPLAINED"].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                statusFilter === st
                  ? "bg-indigo-600 text-white"
                  : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-100"
              }`}
            >
              {st === "ALL"
                ? "All Logs"
                : st.charAt(0) + st.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Logs Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-gray-600">
          <thead className="bg-gray-50 text-gray-500 uppercase font-semibold tracking-wider border-b border-gray-200">
            <tr>
              <th className="py-3 px-4">Recipient</th>
              <th className="py-3 px-4">Subject</th>
              <th className="py-3 px-4">Sending Domain</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white font-mono">
            {isLoading ? (
              <tr>
                <td
                  colSpan="6"
                  className="py-12 text-center text-gray-400 font-sans"
                >
                  Fetching live transmission records...
                </td>
              </tr>
            ) : filteredLogs.length === 0 ? (
              <tr>
                <td
                  colSpan="6"
                  className="py-12 text-center text-gray-400 font-sans"
                >
                  No delivery logs match your filter query.
                </td>
              </tr>
            ) : (
              filteredLogs.map((log) => (
                <tr
                  key={log._id || log.messageId}
                  className="hover:bg-gray-50/80 transition-colors"
                >
                  <td className="py-3 px-4 font-semibold text-gray-900 select-all font-sans">
                    {log.recipient}
                  </td>
                  <td
                    className="py-3 px-4 font-sans text-gray-700 max-w-xs truncate"
                    title={log.subject}
                  >
                    {log.subject}
                  </td>
                  <td className="py-3 px-4 text-gray-500 font-mono text-[11px]">
                    {log.fromDomain || "mail.myproject.com"}
                  </td>
                  <td className="py-3 px-4 font-sans">
                    {getStatusBadge(log.status)}
                  </td>
                  <td className="py-3 px-4 text-gray-400 font-sans text-[11px]">
                    {log.timestamp
                      ? new Date(log.timestamp).toLocaleString()
                      : "N/A"}
                  </td>
                  <td className="py-3 px-4 text-right font-sans">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onSelectLog?.(log)}
                        className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded transition"
                      >
                        Inspect
                      </button>
                      {log.status === "BOUNCED" && onResend && (
                        <button
                          onClick={() => onResend(log)}
                          className="px-2.5 py-1 text-xs font-semibold text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded transition"
                        >
                          Retry
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
