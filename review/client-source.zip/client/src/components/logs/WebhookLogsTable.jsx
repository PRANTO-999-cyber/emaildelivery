import React from "react";
import Badge from "../common/Badge";

/**
 * Stream viewer for incoming tracking webhooks (Opens, Clicks, Unsubscribes, Spam Complaints).
 *
 * @param {Object} props
 * @param {Array<Object>} props.webhooks - List of incoming webhook payloads
 * @param {Function} [props.onSelectPayload] - Triggered to inspect full JSON payload
 */
export default function WebhookLogsTable({ webhooks = [], onSelectPayload }) {
  const getEventTypeBadge = (event) => {
    switch (event?.toLowerCase()) {
      case "open":
        return <Badge variant="success">Open</Badge>;
      case "click":
        return <Badge variant="success">Click</Badge>;
      case "bounce":
        return <Badge variant="danger">Hard Bounce</Badge>;
      case "spamreport":
      case "complaint":
        return <Badge variant="danger">Spam Complaint</Badge>;
      case "unsubscribe":
        return <Badge variant="warning">Opt-Out</Badge>;
      default:
        return <Badge variant="neutral">{event}</Badge>;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden">
      <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-gray-900">
            Live Webhook Event Stream
          </h3>
          <p className="text-xs text-gray-500">
            Real-time open, click, and bounce callbacks from MTA workers.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Listening
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-gray-600">
          <thead className="bg-gray-50 text-gray-500 uppercase font-semibold tracking-wider border-b border-gray-200">
            <tr>
              <th className="py-3 px-4">Event Type</th>
              <th className="py-3 px-4">Recipient</th>
              <th className="py-3 px-4">User Agent / IP</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4 text-right">Payload</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white font-mono">
            {webhooks.length === 0 ? (
              <tr>
                <td
                  colSpan="5"
                  className="py-10 text-center text-gray-400 font-sans"
                >
                  No tracking webhooks received in this window.
                </td>
              </tr>
            ) : (
              webhooks.map((wh, idx) => (
                <tr
                  key={wh._id || idx}
                  className="hover:bg-gray-50/80 transition-colors"
                >
                  <td className="py-3 px-4 font-sans">
                    {getEventTypeBadge(wh.event)}
                  </td>
                  <td className="py-3 px-4 text-gray-900 font-semibold font-sans">
                    {wh.recipient}
                  </td>
                  <td
                    className="py-3 px-4 text-gray-500 text-[11px] max-w-xs truncate"
                    title={wh.userAgent}
                  >
                    {wh.ip ? `${wh.ip} • ` : ""}
                    {wh.userAgent || "MTA Webhook"}
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-[11px] font-sans">
                    {wh.timestamp
                      ? new Date(wh.timestamp).toLocaleTimeString()
                      : "Just now"}
                  </td>
                  <td className="py-3 px-4 text-right font-sans">
                    <button
                      onClick={() => onSelectPayload?.(wh)}
                      className="px-2 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded transition"
                    >
                      JSON
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
