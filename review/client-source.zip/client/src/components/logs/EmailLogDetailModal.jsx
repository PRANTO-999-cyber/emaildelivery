import React, { useState } from "react";

/**
 * Slide-over / Modal window for inspecting raw SMTP handshakes, headers, and cryptographic verification status.
 *
 * @param {Object} props
 * @param {Object} props.log - Log entry details object
 * @param {boolean} props.isOpen - Display toggle flag
 * @param {Function} props.onClose - Modal close callback
 */
export default function EmailLogDetailModal({ log, isOpen, onClose }) {
  const [activeTab, setActiveTab] = useState("OVERVIEW"); // OVERVIEW | HEADERS | EVENTS

  if (!isOpen || !log) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-gray-900/50 backdrop-blur-xs transition-opacity">
      <div className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden">
        {/* Modal Header */}
        <div className="p-6 border-b border-gray-200 flex items-center justify-between bg-slate-900 text-white">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 block font-bold">
              Message-ID: {log.messageId || "msg_1092837482"}
            </span>
            <h3 className="text-base font-bold mt-0.5 truncate max-w-md">
              {log.subject}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-lg font-bold p-1 rounded"
          >
            ✕
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-200 bg-gray-50 px-6 text-xs font-semibold text-gray-600">
          {["OVERVIEW", "HEADERS", "EVENTS"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-3 px-4 border-b-2 transition ${
                activeTab === tab
                  ? "border-indigo-600 text-indigo-600 font-bold bg-white"
                  : "border-transparent hover:text-gray-900"
              }`}
            >
              {tab.charAt(0) + tab.slice(1).toLowerCase()}
            </button>
          ))}
        </div>

        {/* Modal Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {activeTab === "OVERVIEW" && (
            <div className="space-y-4">
              {/* Recipient / Sender Summary */}
              <div className="grid grid-cols-2 gap-4 p-4 rounded-xl bg-gray-50 border border-gray-100">
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase font-bold">
                    From
                  </span>
                  <span className="font-mono font-bold text-gray-800">
                    {log.sender || "noreply@myproject.com"}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase font-bold">
                    Recipient
                  </span>
                  <span className="font-mono font-bold text-gray-800">
                    {log.recipient}
                  </span>
                </div>
              </div>

              {/* Cryptographic Auth Results */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">
                  Cryptographic Verification
                </h4>
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 border rounded-lg bg-emerald-50/50 border-emerald-200">
                    <span className="block font-bold text-emerald-800">
                      SPF
                    </span>
                    <span className="text-[11px] text-emerald-600 font-mono">
                      PASS (ipMatch)
                    </span>
                  </div>
                  <div className="p-3 border rounded-lg bg-emerald-50/50 border-emerald-200">
                    <span className="block font-bold text-emerald-800">
                      DKIM
                    </span>
                    <span className="text-[11px] text-emerald-600 font-mono">
                      PASS (rsa-sha256)
                    </span>
                  </div>
                  <div className="p-3 border rounded-lg bg-emerald-50/50 border-emerald-200">
                    <span className="block font-bold text-emerald-800">
                      DMARC
                    </span>
                    <span className="text-[11px] text-emerald-600 font-mono">
                      PASS (aligned)
                    </span>
                  </div>
                </div>
              </div>

              {/* SMTP Server Response */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">
                  Remote SMTP Response Code
                </h4>
                <pre className="p-3 bg-slate-900 text-emerald-400 rounded-lg font-mono text-[11px] overflow-x-auto">
                  {log.smtpResponse ||
                    "250 2.0.0 OK 1722182041 j12si10293843pkn.42 - gsmtp"}
                </pre>
              </div>
            </div>
          )}

          {activeTab === "HEADERS" && (
            <div className="space-y-2">
              <h4 className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">
                MIME / Message Headers
              </h4>
              <pre className="p-4 bg-slate-950 text-slate-300 rounded-lg font-mono text-[11px] whitespace-pre-wrap overflow-x-auto border border-slate-800 leading-relaxed">
                {log.rawHeaders ||
                  `DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=myproject.com; s=mp;\nReceived: from mail.myproject.com (mail.myproject.com [192.0.2.1])\nTo: <${log.recipient}>\nSubject: ${log.subject}\nList-Unsubscribe: <https://myproject.com/unsubscribe?token=xyz>\nFeedback-ID: cmp_10293:myproject`}
              </pre>
            </div>
          )}

          {activeTab === "EVENTS" && (
            <div className="space-y-3">
              <h4 className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">
                Tracking Event Telemetry
              </h4>
              <div className="space-y-2 border-l-2 border-indigo-200 pl-4">
                {(
                  log.events || [
                    {
                      type: "QUEUED",
                      time: "12:00:01 PM",
                      detail: "Dispatched to worker queue",
                    },
                    {
                      type: "DELIVERED",
                      time: "12:00:03 PM",
                      detail: "Accepted by MX server",
                    },
                    {
                      type: "OPENED",
                      time: "12:04:12 PM",
                      detail: "Tracking pixel triggered (Chrome/Mac OS)",
                    },
                  ]
                ).map((evt, idx) => (
                  <div key={idx} className="relative">
                    <span className="font-bold text-gray-800 block">
                      {evt.type}
                    </span>
                    <span className="text-gray-500 font-mono text-[11px] block">
                      {evt.time}
                    </span>
                    <span className="text-gray-600 text-[11px] block">
                      {evt.detail}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-gray-200 bg-gray-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 hover:bg-gray-300 font-semibold text-gray-700 rounded-lg text-xs"
          >
            Close Modal
          </button>
        </div>
      </div>
    </div>
  );
}
